package navegadorWebHttp;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.text.html.HTMLEditorKit;

import javax.swing.JButton;
import javax.swing.JEditorPane;

/**
 * Clase que lanza peticiones Http para hacer consultas en Google. El resultado
 * de la peticion Http es una pagina html, que se muestra como si fuese un
 * navegador web normal pero sin CSS.
 * 
 * El protocolo HTTP es el protocolo de comunicación que permite las
 * transferencias de información a través de archivos (XML, HTML…) en Intenet.
 * Es un protocolo sin estado, no guarda ninguna información sobre conexiones
 * anteriores. Esta basado en mensajes, y su arquitectura es la clasica
 * Cliente/Servidor,
 * 
 * HTTP establece una serie de peticiones, las mas usadas son GET, POST, PUT y
 * DELETE, que suelen corresponderse con operaciones SELECT, INSERT, UPDATE y
 * DELETE de SQL en el Servidor; pero existen otras.
 * 
 * HTTP establece tambien una serie de codigos de respuesta para indicar lo que
 * ha pasado con la peticion. P.Ej: los codigos con formato 2xx significan
 * Respuestas correctas; los codigos con formato 4xx significan Errores causados
 * por el cliente. Adicionalmente, las respuestas pueden contener (o no)
 * ficheros con la informacion solicitada por el cliente, usualmente en formato
 * XML, HTM o JSON
 */
public class CuteWebBrowser {

	private static final String SCHEMA = "https://";
	private static final String SERVER = "www.google.es/search?q=";

	private JFrame myCuteBrowser;
	private JTextField textField;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CuteWebBrowser window = new CuteWebBrowser();
					window.myCuteBrowser.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public CuteWebBrowser() {
		myCuteBrowser = new JFrame();
		myCuteBrowser.setResizable(false);
		myCuteBrowser.setTitle("My Cute Little Browser!");
		myCuteBrowser.setBounds(100, 100, 450, 300);
		myCuteBrowser.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		myCuteBrowser.getContentPane().setLayout(null);

		JLabel lblNewLabel = new JLabel("Palabra ");
		lblNewLabel.setBounds(10, 11, 60, 14);
		myCuteBrowser.getContentPane().add(lblNewLabel);

		textField = new JTextField();
		textField.setBounds(80, 8, 234, 20);
		myCuteBrowser.getContentPane().add(textField);
		textField.setColumns(10);

		JEditorPane jEditorPane = new JEditorPane();
		jEditorPane.setEditorKit(new HTMLEditorKit());
		jEditorPane.setContentType("text/html");
		jEditorPane.setEditable(false);

		JScrollPane jScrollPane = new JScrollPane(jEditorPane);
		jScrollPane.setBounds(10, 37, 414, 199);
		myCuteBrowser.getContentPane().add(jScrollPane);

		JButton btnNewButton = new JButton("Buscar");
		btnNewButton.setBounds(335, 7, 89, 23);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (textField.getText().length() != 0) {

					// Buscamos la palabra del textField
					String pagina = buscar(textField.getText());

					if (null == pagina) {
						jEditorPane.setText("<html>Page not found.</html>");
					} else {
						jEditorPane.setText(pagina);
					}
				} else {
					JOptionPane.showMessageDialog(new JFrame(), "Falta la palabra a buscar");
				}
			}
		});
		myCuteBrowser.getContentPane().add(btnNewButton);
	}

	/**
	 * Lanza una peticion Http tipo GET al buscador de google. Retorna la pagina web
	 * en codigo html; el error del servidor de la RAE; o NULL si algo sale mal
	 * 
	 * @param palabra
	 * @return la pagina web de respuesta, el error o null
	 */
	private String buscar(String palabra) {
		String ret = null;
		try {
			// Montamos la direccion del recurso
			String resource = URLEncoder.encode(palabra, StandardCharsets.UTF_8.name());
			String direccion = SCHEMA + SERVER + resource;

			// Abrimos la conexion. Ponemos los datos de la cabecera de la
			// request HTTP.
			@SuppressWarnings("deprecation")
			URL url = new URL(direccion);
			HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
			httpURLConnection.setRequestMethod("GET");
			httpURLConnection.setRequestProperty("Conetent-type", "text/plain");
			httpURLConnection.setRequestProperty("charset", "utf-8");
			httpURLConnection.setRequestProperty("User-Agent", "Mozilla/5.0");

			// En este caso, la request no tiene cuerpo (es un GET)

			// Envio de la peticion y obtenemos la respuesta
			int codigoRespuestaHttp = httpURLConnection.getResponseCode();

			// La respuesta de http SIEMPRE consta de un codigo HTTP; y
			// un cuerpo opcional. En este caso, nos devuelve una pagian web

			// Vemos que codigo http nos llega de google. SI es 200 - OK
			StringBuilder respuesta = new StringBuilder();
			if (codigoRespuestaHttp == HttpURLConnection.HTTP_OK) {

				// Leemos el cuerpo de la respuesta (la web)
				Reader reader = new InputStreamReader(httpURLConnection.getInputStream());
				int myByte;
				while ((myByte = reader.read()) != -1) {
					respuesta.append((char) myByte);
				}
				ret = respuesta.toString();

			} else {
				// Si nos devuelve otro codigo http diferente, tenemos que tratarlo
				// por nuestra cuenta

				// 500 - Internal Server Error y 404 Not Found
				switch (codigoRespuestaHttp) {
				case HttpURLConnection.HTTP_INTERNAL_ERROR:
					ret = "Servidor respondio: Internal Server Error";
					break;
				case HttpURLConnection.HTTP_NOT_FOUND:
					ret = "Servidor respondio: Not Found";
					break;
				default:
					ret = "Servidor respondio: HTTP Code Error : " + codigoRespuestaHttp;
				}
			}
			httpURLConnection.disconnect();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return ret;
	}

}
