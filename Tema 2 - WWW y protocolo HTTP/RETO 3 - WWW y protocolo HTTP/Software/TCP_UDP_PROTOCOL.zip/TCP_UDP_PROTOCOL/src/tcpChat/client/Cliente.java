package tcpChat.client;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.JTextArea;

/**
 * Gestiona un socket, del que obtiene un dataOutputStream y un dataInputStream.
 * El dataOutputStream (envio) se gestiona directamente. El dataInputStream
 * (escucha) se gestiona en el hilo HiloEscucha.
 * 
 * @author Iker Mezkorta, Borja Saiz (adaptacion)
 */
public class Cliente {

	private Socket socket = null;
	private DataOutputStream dataOutputStream = null;
	private DataInputStream dataInputStream = null;
	private JTextArea jTextArea = null;

	private HiloEscucha hiloEscucha = null;

	// Hilo que gestiona la escucha...
	class HiloEscucha extends Thread {

		public void run() {
			String mensaje = "";

			// Espera indefinida hasta que llega un *
			while (!mensaje.equals("*")) {
				try {
					while (!mensaje.equals("*")) {
						dataInputStream = new DataInputStream(socket.getInputStream());
						mensaje = dataInputStream.readUTF(); // Espera a leer algo...

						if (!mensaje.equals("*"))
							jTextArea.append(mensaje + System.lineSeparator());
						else
							jTextArea.append("Servidor desconectado");
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public Cliente(String ipServer, int puertoServer, JTextArea jTextArea) {
		try {
			socket = new Socket(ipServer, puertoServer);
			this.jTextArea = jTextArea;

			hiloEscucha = new HiloEscucha();
			hiloEscucha.start();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void enviarMensaje(String mensaje) {
		try {
			dataOutputStream = new DataOutputStream(socket.getOutputStream());
			dataOutputStream.writeUTF(mensaje);
			dataOutputStream.flush();
		} catch (UnknownHostException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	public void cerrarConexiones() {
		try {
			if (null != dataOutputStream)
				dataOutputStream.close();
		} catch (IOException ioe) {
			// No importa...
		}
		try {
			if (null != dataInputStream)
				dataInputStream.close();
		} catch (IOException ioe) {
			// No importa...
		}
		try {
			if (null != socket)
				socket.close();
		} catch (IOException ioe) {
			// No importa...
		}
	}
}
