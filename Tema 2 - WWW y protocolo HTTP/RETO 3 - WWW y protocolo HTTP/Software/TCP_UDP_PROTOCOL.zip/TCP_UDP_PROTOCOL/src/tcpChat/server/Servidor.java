package tcpChat.server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JTextArea;

public class Servidor extends Thread {

	private static final int MAX_CONNECTIONS = 3;

	private ServerSocket serverSocket = null;
	private List<HiloServer> listaClientes;

	private JTextArea jTextArea = null;
	private int puertoServer = 0;

	private static boolean continuar = true;
	
	// Hilo que gestiona el server...
	class HiloServer extends Thread {

		private Socket socket;
		private DataInputStream dataInputStream = null;
		private DataOutputStream dataOutputStream = null;
		
		public HiloServer(Socket socket) {
			this.socket = socket;
		}

		public DataInputStream getDataInputStream() {
			return dataInputStream;
		}
		
		public DataOutputStream getDataOutputStream() {
			return dataOutputStream;
		}

		public void run() {
			String mensaje = "";

			// Espera indefinida hasta que llega un *
			while ((continuar) && (!mensaje.equals("*"))) {
				try {
					dataInputStream = new DataInputStream(socket.getInputStream());
					dataOutputStream = new DataOutputStream(socket.getOutputStream());
					
					while ((continuar) && (!mensaje.equals("*"))) {
						mensaje = dataInputStream.readUTF();

						if (!mensaje.equals("*")) {
							jTextArea.append(mensaje + System.lineSeparator());
							for (HiloServer hiloServer : listaClientes) {
								DataOutputStream dataOutputStream = hiloServer.getDataOutputStream();
								dataOutputStream.writeUTF(mensaje);
								dataOutputStream.flush();
							}
						} else {
							jTextArea.append("Servidor desconectado");
						}
					}
				} catch (IOException e) {
					e.printStackTrace();
				} finally {
					try {
						if (null != dataInputStream)
							dataInputStream.close();
					} catch (IOException ioe) {
						// No importa...
					}
					try {
						if (null != dataOutputStream)
							dataOutputStream.close();
					} catch (IOException ioe) {
						// No importa...
					}
				}
			}
		}
	}

	public Servidor(int puertoServer, JTextArea jTextArea) {
		this.puertoServer = puertoServer;
		listaClientes = new ArrayList<HiloServer>();
		this.jTextArea = jTextArea;
	}

	@Override
	public void run() {

		Socket socket = null;
		try {
			serverSocket = new ServerSocket(puertoServer);
			while (continuar) {
				socket = serverSocket.accept(); // En espera...

				if (listaClientes.size() < MAX_CONNECTIONS) {
					HiloServer hiloServer = new HiloServer(socket);
					listaClientes.add(hiloServer);
					hiloServer.start();
				} else {
					// No admitimos esta conexion...
					try {
						socket.close();
					} catch (Exception e) {
						// No importa...
					}
				}
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	public void desconectar() {
		continuar = false;
		
		try {
			// Cerramos todos los clientes y finalizamos los hilos...
			for (HiloServer hiloServer : listaClientes) {
				DataOutputStream dataOutputStream = hiloServer.getDataOutputStream();
				dataOutputStream.writeUTF("*");
				dataOutputStream.flush();
			}

			try {
				if (null != serverSocket)
					serverSocket.close();
			} catch (IOException ioe) {
				// No importa...
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}