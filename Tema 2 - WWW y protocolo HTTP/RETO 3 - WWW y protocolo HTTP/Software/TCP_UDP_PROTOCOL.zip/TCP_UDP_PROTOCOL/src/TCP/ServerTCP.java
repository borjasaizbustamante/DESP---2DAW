package TCP;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * Clase que define un servidor que escucha peticiones TCP. Nos mandan un objeto
 * Persona con un nombre, y si es "Juan" respondemos enviando otro objeto con
 * todos sus datos.
 * 
 * Un ServerSocket es una clase de Java que escucha el trafico de red en el
 * puerto que le indiques. Lo que le llega son flujos de bytes, no tenemo ni
 * idea de lo que es, asi que nos toca procesarlo a mano.
 * 
 * El objetivo de TCP es crear conexiones dentro de una red para intercambiar
 * datos. Además, garantiza que los datos llegaran a destino sin errores y en el
 * mismo orden en el que fueron transmitidos.
 */
public class ServerTCP {

	private static final int PORT = 49171; // Coge uno libre...

	public static void main(String[] args) {

		ServerSocket serverSocket = null;
		Socket socket = null;
		InputStream inputStream = null;
		OutputStream outputStream = null;
		ObjectOutputStream objectOutputStream = null;
		ObjectInputStream objectInputStream = null;
		int puertoServer = PORT;

		// El servidor nunca termina...
		while (true) {
			try {
				serverSocket = new ServerSocket(puertoServer);

				// Nos ponemos a esperar hasta que llega algo al puerto...
				socket = serverSocket.accept();

				// Leemos lo que sea que haya llegado y lo convertimos en Persona
				inputStream = socket.getInputStream();
				objectInputStream = new ObjectInputStream(inputStream);
				Persona persona = (Persona) objectInputStream.readObject();

				System.out.println("Server - Recibido: " + persona.getNombre());

				// Vamos a respodner al cliente...
				outputStream = socket.getOutputStream();

				// Si nos han mandado a "Juan" respondemos...
				if (persona.getNombre().equals("Juan")) {
					persona = new Persona("111111111E", "Padre de Juan", "Perez",
							new SimpleDateFormat("dd/MM/yyyy").parse("12/12/2012"));
				} else {
					persona = new Persona();
				}

				// Lo enviamos
				outputStream = socket.getOutputStream();
				objectOutputStream = new ObjectOutputStream(outputStream);
				objectOutputStream.writeObject(persona);

			} catch (IOException | ClassNotFoundException | ParseException ioe) {
				ioe.printStackTrace();
			} finally {
				try {
					if (null != outputStream)
						outputStream.close();
				} catch (IOException e) {
					// No importa...
				}
				try {
					if (null != inputStream)
						inputStream.close();
				} catch (IOException e) {
					// No importa...
				}
				try {
					if (null != socket)
						socket.close();
				} catch (IOException e) {
					// No importa...
				}
				try {
					if (null != serverSocket)
						serverSocket.close();
				} catch (IOException e) {
					// No importa...
				}
			}
		}
	}
}
