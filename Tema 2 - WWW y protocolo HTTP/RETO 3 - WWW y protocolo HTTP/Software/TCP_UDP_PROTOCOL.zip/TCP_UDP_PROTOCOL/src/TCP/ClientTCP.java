package TCP;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.text.ParseException;
import java.text.SimpleDateFormat;

/**
 * Clase que define un cliente que envia peticiones TCP. Nos mandan un objeto
 * Persona con un nombre, y si es "Juan" respondemos enviando otro objeto con
 * todos sus datos.
 * 
 * Un Socket es una clase de Java que envía cosas por el puerto que le
 * indiquesen forma de flujos de bytes.
 * 
 * El objetivo de TCP es crear conexiones dentro de una red para intercambiar
 * datos. Además, garantiza que los datos llegaran a destino sin errores y en el
 * mismo orden en el que fueron transmitidos.
 */
public class ClientTCP {

	private static final String IP = "127.0.0.1";
	private static final int PORT = 49171; // Coge uno libre...

	public static void main(String[] args) {

		Socket socket = null;
		InputStream inputStream = null;
		OutputStream outputStream = null;
		ObjectOutputStream objectOutputStream = null;
		ObjectInputStream objectInputStream = null;
		String ipServer = IP;
		int puertoServer = PORT;

		try {
			// Preparamos el socket para enviar
			socket = new Socket(ipServer, puertoServer);
			outputStream = socket.getOutputStream();
			objectOutputStream = new ObjectOutputStream(outputStream);

			// Mandamos un objeto persona con el nombre de "Juan"
			Persona persona = new Persona("111111111E", "Juan", "Perez",
					new SimpleDateFormat("dd/MM/yyyy").parse("12/12/2012"));
			objectOutputStream.writeObject(persona);

			// ... e inmediatamente el servidor nos responde (porque es muy rapido) 
			inputStream = socket.getInputStream();
			objectInputStream = new ObjectInputStream(inputStream);
			persona = (Persona) objectInputStream.readObject();

			System.out.println("Cliente - Mensaje de respuesta: " + persona.getNombre());

		} catch (IOException | ClassNotFoundException | ParseException ioe) {
			ioe.printStackTrace();
		} finally {
			try {
				if (null != outputStream)
					outputStream.close();
			} catch (IOException e) {
				// No importa...
			}
			try {
				if (null != inputStream)
					inputStream.close();
			} catch (IOException e) {
				// No importa...
			}
			try {
				if (null != socket)
					socket.close();
			} catch (IOException e) {
				// No importa...
			}
		}
	}
}
