package UDP;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

/**
 * Clase que define un servidor que escucha peticiones UDP. Nos mandan 10000
 * peticiones UDP con el objetivo de que el Server las procese segun le llegan,
 * lo que no deberia ser en el orden en el que se envian.
 * 
 * Un DatagramPacket es una clase de Java que escucha el trafico de red en el
 * puerto que le indiques. 
 * 
 * El objetivo de UDP es crear conexiones dentro de una red para intercambiar
 * datos. A diferencia de TCP, no establece primero una conexion y NO garantiza
 * que los datos llegaran a destino sin errores NI en el mismo orden en el que
 * fueron transmitidos.
 */
public class ServerUDP {

	private static final int PORT = 49171; // Coge uno libre...

	public static void main(String[] args) {

		DatagramSocket datagramSocket = null;
		DatagramPacket datagramPacketIn = null;

		int puertoServer = PORT;

		try {
			datagramSocket = new DatagramSocket(puertoServer);

			boolean isEnd = false;
			while (!isEnd) {
				System.out.println("Servidor - Esperando conexiones de Clientes...");

				byte[] bufferLectura = new byte[64];
				datagramPacketIn = new DatagramPacket(bufferLectura, bufferLectura.length);
				datagramSocket.receive(datagramPacketIn); // En espera...

				String mensajeRecibido = new String(bufferLectura);
				mensajeRecibido = mensajeRecibido.trim();
				if ((null != mensajeRecibido) && (mensajeRecibido.equalsIgnoreCase("END"))) {
					System.out.println("Servidor - Finalizamos");
					isEnd = true;
				} else
					System.out.println("Servidor - " + mensajeRecibido);
			}
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} finally {
			System.out.println("Servidor - Cerrando conexiones...");
			datagramSocket.close();
		}

		System.out.println("Servidor - Finalizado!");
	}
}
