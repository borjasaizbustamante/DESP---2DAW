package UDP;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

/**
 * Clase que define un cliente que envia 10000 peticiones UDP con el objetivo de
 * que el Server las procese segun le llegan, lo que no deberia ser en el orden
 * en el que se envian.
 * 
 * Un DatagramPacket es una clase de Java que envía cosas por el puerto que le
 * indiquesen.
 * 
 * El objetivo de UDP es crear conexiones dentro de una red para intercambiar
 * datos. A diferencia de TCP, no establece primero una conexion y NO garantiza
 * que los datos llegaran a destino sin errores NI en el mismo orden en el que
 * fueron transmitidos.
 */
public class ClientUDP extends Thread {

	private static final String IP = "127.0.0.1";
	private static final int PORT = 49171; // Coge uno libre...

	public static void main(String[] args) {
		DatagramSocket datagramSocket = null;
		DatagramPacket datagramPacketOut = null;
		InetAddress inetAddress = null;

		String ipServer = IP;
		int puertoServer = PORT;

		try {

			// Preparamos en envío de peticiones UDP
			System.out.println("Cliente - Preparando para conectar con " + ipServer + ":" + puertoServer);
			inetAddress = InetAddress.getByName(ipServer); // Que otro me busque la IP...

			System.out.println("Cliente - Intento de conexion");
			datagramSocket = new DatagramSocket();

			// Envio masivo de peticiones...
			String mensaje = "Mensaje numero ";
			for (int i = 0; i < 10000; i++) {
				byte[] bufferEscritura = new String(mensaje + i).getBytes();
				datagramPacketOut = new DatagramPacket(bufferEscritura, bufferEscritura.length, inetAddress,
						puertoServer);
				datagramSocket.send(datagramPacketOut);
			}

			// Le decimos que hemos acabado 'a mano' porque a UDP eso le da igual
			mensaje = "END";
			byte[] bufferEscritura = new String(mensaje).getBytes();
			datagramPacketOut = new DatagramPacket(bufferEscritura, bufferEscritura.length, inetAddress, puertoServer);
			datagramSocket.send(datagramPacketOut);

			System.out.println("Cliente - Mensajes enviados");

		} catch (IOException ioe) {
			ioe.printStackTrace();
		} finally {
			System.out.println("Cliente - Cerrando conexiones...");
			datagramSocket.close();
		}

		System.out.println("Cliente - Finalizado!");
	}
}
