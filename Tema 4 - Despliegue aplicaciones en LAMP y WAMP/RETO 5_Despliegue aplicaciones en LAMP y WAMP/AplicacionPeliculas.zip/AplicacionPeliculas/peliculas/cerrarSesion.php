<?php 


include_once("sesiones.php");
//Se cierra la sesi�n
cerrar_sesion();


?>
<html>
       <SCRIPT LANGUAGE="javascript">
          location.href = "index.php"; 
       </SCRIPT>
</html>