use tomcatusers;

insert into users values("mortadelo","mortadelo");
insert into users values("filemon","filemon");
insert into users_roles values("mortadelo","compras");
insert into users_roles values("filemon","compras");
